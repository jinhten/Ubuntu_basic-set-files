# Changelog

## 2.1.0 - 2019-05-05
### Added
- Added TypeScript type definitions. See [#17](https://github.com/helmetjs/nocache/issues/17) and [helmetjs/helmet#188](https://github.com/helmetjs/helmet/issues/188)
- Created a changelog

### Changed
- Excluded some files from npm package
- Updated some package metadata

Changes in versions 2.0.0 and below can be found in [Helmet's changelog](https://github.com/helmetjs/helmet/blob/master/CHANGELOG.md).
