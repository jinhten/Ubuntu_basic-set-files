'use strict';
module.exports = {
	info: 'ℹ️',
	success: '✅',
	warning: '⚠️',
	error: '❌️'
};
