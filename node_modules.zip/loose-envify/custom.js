// envify compatibility
'use strict';

module.exports = require('./loose-envify');
